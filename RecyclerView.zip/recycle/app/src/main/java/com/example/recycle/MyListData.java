package com.example.recycle;

class MyListData {

    String Text;
    int imgid;

    public MyListData(String text, int imgid) {
        Text = text;
        this.imgid = imgid;
    }

    public String getText() {
        return Text;
    }

    public void setText(String text) {
        this.Text = text;
    }

    public int getImgid() {
        return imgid;
    }

    public void setImgid(int imgid) {
        this.imgid = imgid;
    }
}
